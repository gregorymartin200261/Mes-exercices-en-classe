﻿using System;

namespace categoriserselonage
{
    class Program
    {
        static void Main(string[] args)
        {
            

            Console.WriteLine("entre ton age");
            int age = 0;
            age = Convert.ToInt32(Console.ReadLine());
            if (age <= 5 || age > 14) 
                {
                Console.WriteLine("Tu n'appartient a aucune categorie");
                }
            else if (age <= 7) 
                    {
                     Console.WriteLine("Tu appartient a la categorie poussin");
                    }
                else if (age <= 9) 
                        {
                            Console.WriteLine("Tu appartient a la categorie pupile");
                        }
                      else if (age <= 11) 
                            {
                             Console.WriteLine("Tu appartient a la categorie minime");
                            }
                            else 
                                {
                                Console.WriteLine("Tu appartient a la categorie cadet");
                                }
        }
    }
}
