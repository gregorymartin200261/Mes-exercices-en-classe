﻿using System;

namespace table_de_5
{
    class Program
    {
        static void Main(string[] args)
        {
            nombre = int;
            nombre = 0;
            for (int n = 1; n <= 100; n++)
                total=n*5
                nombre= (nombre + ","+total)
            Console.WriteLine(nombre)
        }


    }
}
